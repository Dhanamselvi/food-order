package com.order.application.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.order.application.entity.Order;



// @Repository
public interface OrderRepository extends JpaRepository<Order,Long> {
	

}
