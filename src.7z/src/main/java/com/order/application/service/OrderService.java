package com.order.application.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.application.entity.Order;
import com.order.application.repository.OrderRepository;

@Service 
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepo;
	
	public void saveOrder(Order order) {
		
		orderRepo.save(order);
		
	}
	
	
	
}
