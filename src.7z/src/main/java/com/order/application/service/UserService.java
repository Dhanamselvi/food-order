package com.order.application.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.order.application.entity.User;
import com.order.application.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepo;

	
	public boolean loginValidation(User user) {
		
		Optional<User> existUser;
		existUser=userRepo.findById(user.getUserName());
		System.out.print("is Existing user"+ existUser);
				if(existUser.isEmpty()) {
					return false;
				}
		else{
			return true;
		}
		
		
		
	}
	
	public User saveUser(User user) {
		
		user.setId(userRepo.save(user).getId());
		return user;
		
	}
	
	
	/*
	 * public Optional<User> verifyUserNamePassword(String userName, String
	 * password) {
	 * 
	 * Optional<User> userDetails =
	 * Optional.ofNullable(userRepo.findByUserNameAndPassword(userName, password));
	 * return userDetails; }
	 */

}
