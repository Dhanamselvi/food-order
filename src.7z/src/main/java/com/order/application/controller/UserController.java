package com.order.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.order.application.entity.User;
import com.order.application.service.UserService;



@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserService userService;
	
	@PostMapping("/save")
	public ResponseEntity<Object> saveUserByCustomer(@RequestBody User user) {
		return new ResponseEntity<>(userService.saveUser(user), HttpStatus.OK);
	}
//	@PostMapping("/login")
//	public ResponseEntity<Object> doLogin(@RequestBody User user) {
//		
//		return new ResponseEntity<>(userService.verifyUserNamePassword(user.getUserName(), user.getPassword()), HttpStatus.OK);
//
//	}
	
	
	@PostMapping("/login")
	public boolean doLogin(@RequestBody User user) {
		boolean isValidUser = userService.loginValidation(user);
		return isValidUser;
		

	}
	
	
}
